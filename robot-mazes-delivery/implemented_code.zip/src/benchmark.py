import benchmark.benchmarker

if __name__ == '__main__':
    benchmark.benchmarker.benchmark()